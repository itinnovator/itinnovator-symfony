<?php

namespace Projects\Bundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class ProjectsBundle extends Bundle
{
}
