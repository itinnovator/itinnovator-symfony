<?php

/* CoreBundle:Default:index.html.twig */
class __TwigTemplate_c8baa12f0e1d3194154d121cdb16675bbe9670526fabe23f88b1cd624dc0a966 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_787b252a168d4f14a877252e30419b114f2634cb6f69f9f207a9a8eb1df9b169 = $this->env->getExtension("native_profiler");
        $__internal_787b252a168d4f14a877252e30419b114f2634cb6f69f9f207a9a8eb1df9b169->enter($__internal_787b252a168d4f14a877252e30419b114f2634cb6f69f9f207a9a8eb1df9b169_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "CoreBundle:Default:index.html.twig"));

        // line 1
        echo "Hello World!
";
        
        $__internal_787b252a168d4f14a877252e30419b114f2634cb6f69f9f207a9a8eb1df9b169->leave($__internal_787b252a168d4f14a877252e30419b114f2634cb6f69f9f207a9a8eb1df9b169_prof);

    }

    public function getTemplateName()
    {
        return "CoreBundle:Default:index.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* Hello World!*/
/* */
