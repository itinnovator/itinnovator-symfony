<?php

/* ProjectsBundle:Default:index.html.twig */
class __TwigTemplate_579c807677dacd0a217c81e65e0f1e5ec36ebbf878e15e8981cfd1466b0f7555 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_7bdf3362d1f8473398ce70e5344acb0a352d01ad186d384b8f610a385931fd7f = $this->env->getExtension("native_profiler");
        $__internal_7bdf3362d1f8473398ce70e5344acb0a352d01ad186d384b8f610a385931fd7f->enter($__internal_7bdf3362d1f8473398ce70e5344acb0a352d01ad186d384b8f610a385931fd7f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "ProjectsBundle:Default:index.html.twig"));

        // line 1
        echo "Hello World!
";
        
        $__internal_7bdf3362d1f8473398ce70e5344acb0a352d01ad186d384b8f610a385931fd7f->leave($__internal_7bdf3362d1f8473398ce70e5344acb0a352d01ad186d384b8f610a385931fd7f_prof);

    }

    public function getTemplateName()
    {
        return "ProjectsBundle:Default:index.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* Hello World!*/
/* */
